from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix, classification_report
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
import xgboost as xgb
import seaborn as sns
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE
from sklearn.utils.class_weight import compute_class_weight
import shap
import joblib

def get_category_probabilities(sample_probs, val):
    return {
        "actual yards": val,
        "0 yards": sample_probs[0:2].sum(),
        "1-5 yards": sample_probs[3:5].sum(),
        "6-8 yards": sample_probs[6:8].sum(),
        "9+ yards": sample_probs[9:].sum()
    }

# Data preparation
input_df = pd.read_csv(r"SD/model_input_df_pass_catch_with_friends.csv", 
                      usecols=["receiverx", "receivery", "receivers", "receivera", "receiverdis", 
                               "receiverdir", "distance_to_nearest_def", "defenders_in_path",
                              "friends_in_path", "pass_length",  "yardline_num", "yards_gained"])

input_df = input_df[input_df["pass_length"] > 0]

# Feature engineering
def bucket_separation(distance):
    if distance < 0.5: return 0
    elif 0.5 <= distance < 2.0: return 1
    elif 3 <= distance < 5.0: return 2
    elif 6 <= distance < 8.0: return 3
    else: return 4

def bucket_friends(count):
    if count == 0: return 0
    elif 1 <= count <= 2: return 1
    elif 3 <= count <= 4: return 2
    else: return 3

input_df["defender_separation_encoded"] = input_df["distance_to_nearest_def"].apply(bucket_separation)
input_df["friends_bucket"] = input_df["friends_in_path"].apply(bucket_friends)
input_df["blocking_advantage"] = input_df["friends_bucket"] - np.floor(input_df["defenders_in_path"] / 2)
input_df["separation_x_pass_length"] = input_df["defender_separation_encoded"] * input_df["pass_length"]

# 1. Receiver's positioning advantage (sideline vs. middle)
input_df["receiver_near_sideline"] = (np.abs(input_df["receiverx"]) > 15).astype(int)

# 2. Defender density ratio
input_df["defender_density_ratio"] = input_df["defenders_in_path"] / (input_df["distance_to_nearest_def"] + 0.1)

# 3. Directional momentum (receiver speed × direction)
input_df["receiver_momentum"] = input_df["receivers"] * np.cos(np.radians(input_df["receiverdir"]))



input_df["defender_pressure"] = (
    input_df["defenders_in_path"] * 
    np.where(input_df["receivera"] < 0, 1.5, 1.0) *  # Amplify if decelerating
    (1 / (input_df["distance_to_nearest_def"] + 0.5)  # Inverse distance weighting
))

# Create tackle probability feature
input_df["tackle_indicators"] = (
    (input_df["defenders_in_path"] >= 2) & 
    (input_df["receivera"] < 0)
).astype(int)


# Prepare features and target
x = input_df[[
    "friends_bucket",
    "defender_separation_encoded",
    "blocking_advantage",
    "separation_x_pass_length",
    "receiverx",
    "receivery",
    "receivers",
    "receivera",
    "receiverdis",
    
    "receiverdir",
    "defenders_in_path",
    "pass_length",
    
    "receiver_momentum" ,
    "defender_density_ratio" ,
    "receiver_near_sideline",
    "defender_pressure",
    "tackle_indicators",
    "distance_to_nearest_def"
]].copy()
 
# Define feature weights (higher = more important)
feature_weights = {
    "friends_bucket": 1.5,               # 3x weight - most critical for YAC
    "blocking_advantage": 1.5,            # 2.5x weight
    "defender_density_ratio": 2.75,        # 2x weight
    "defender_separation_encoded": 2.0,   # 1.8x weight
    "separation_x_pass_length": 1.5,      # 1.5x weight
    "receiver_momentum": 1.5,             # New dynamic feature
    "receivers": 3.0,
    "receiverdir": 2.5,
    "pass_length": 2.25,
    "receivery": 2.0,
    "distance_to_nearest_def": 10,
    # All other features get default weight of 1.0
}

y = input_df["yards_gained"].clip(lower=0).apply(
    lambda y: 0 if y <= 2 else 1 if 3 <= y <= 6 else 2 if 7 <= y <= 9 else 3
)

# Model training
params = {
    "max_depth": 8,
    "min_child_weight": 1,
    "booster": "gbtree",
    "objective": "multi:softprob",
    "eval_metric": "mlogloss",
    "num_class": 4,
    "subsample": 0.8,
    "gamma": 0.3,
    "eta": 0.01,
    "colsample_bytree": 0.7,
    
}

kfold = KFold(n_splits=5, shuffle=True, random_state=7)
all_preds = []
all_true = []

for fold, (train_idx, test_idx) in enumerate(kfold.split(x)):
    print(f"Fold {fold + 1}")
    
    x_train, x_test = x.iloc[train_idx], x.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    
    smote = SMOTE(sampling_strategy={1: 1500, 2: 1300, 3: 1100}, k_neighbors=4, random_state=7)
    x_train, y_train = smote.fit_resample(x_train, y_train)
    
    class_weights = compute_class_weight("balanced", classes=np.unique(y_train), y=y_train)
    weight_dict = dict(zip(np.unique(y_train), class_weights))
    weight_dict[2] = 0.8  # Adjust weight for 1-5 yards class
    
    sample_weights = y_train.map(weight_dict)
    
    # Apply feature weights here
    dtrain = xgb.DMatrix(
        x_train,
        label=y_train,
        weight=sample_weights,
        feature_weights=[feature_weights.get(col, 1.0) for col in x_train.columns]
    )
    
    dtest = xgb.DMatrix(x_test)
    
    model = xgb.train(params, dtrain, num_boost_round=5000)
    preds = model.predict(dtest)
    all_preds.append(preds)
    all_true.append(y_test.reset_index(drop=True))

# Combine results
preds_concat = np.vstack(all_preds)
true_labels = pd.concat(all_true, ignore_index=True)
predicted_classes = np.argmax(preds_concat, axis=1)



# Evaluation
class_names = ["0-2yards", "3-5 yards", "6-8 yards", "9+ yards"]
cm = confusion_matrix(true_labels, predicted_classes)
print("Confusion Matrix:\n", cm)
print("\nClassification Report:\n", classification_report(true_labels, predicted_classes, target_names=class_names))

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.title("Confusion Matrix")
plt.show()


xgb.plot_importance(model)
plt.show()

joblib.dump(model, "xgboost.joblib")

#insert here


        
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix, classification_report
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
import xgboost as xgb
import seaborn as sns
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE
from sklearn.utils.class_weight import compute_class_weight
import shap
import joblib




#SAVING RELOADING AND RANKING WITH MODEL
#model.save_model("xgbModel.json")

model = joblib.load(r"C:\Users\wolve\Desktop\New folder\xgboost.joblib")

input_df = pd.read_csv(r"C:\Users\wolve\Desktop\New folder\SD\model_input_from_yolo.csv", 
                      usecols=["receiverID", "receiverx", "receivery", "receivers", "receivera", "receiverdis", "receiverdir", "distance_to_nearest_def", "defenderx",
     "defendery", "defenders", "defendera", "defenderdis", "defenderdir", "defenders_in_path","friends_in_path", "pass_length"])

#Do not try to pass to players behind the QB
input_df = input_df[input_df["pass_length"] > 0]

def bucket_separation(distance):
    if distance < 0.5: return 0
    elif 0.5 <= distance < 2.0: return 1
    elif 3 <= distance < 5.0: return 2
    elif 6 <= distance < 8.0: return 3
    else: return 4

def bucket_friends(count):
    if count == 0: return 0
    elif 1 <= count <= 2: return 1
    elif 3 <= count <= 4: return 2
    else: return 3

#Preparing features for use in the model
pass_lengths = input_df["pass_length"]
input_df["defender_separation_encoded"] = input_df["distance_to_nearest_def"].apply(bucket_separation)
input_df["friends_bucket"] = input_df["friends_in_path"].apply(bucket_friends)
input_df["blocking_advantage"] = input_df["friends_bucket"] - np.floor(input_df["defenders_in_path"] / 2)
input_df["separation_x_pass_length"] = input_df["defender_separation_encoded"] * input_df["pass_length"]

# 1. Receiver's positioning advantage (sideline vs. middle)
input_df["receiver_near_sideline"] = (np.abs(input_df["receiverx"]) > 30).astype(int)

# 2. Defender density ratio
input_df["defender_density_ratio"] = input_df["defenders_in_path"] / (input_df["distance_to_nearest_def"] + 0.1)

# 3. Directional momentum (receiver speed × direction)
input_df["receiver_momentum"] = input_df["receivers"] * np.cos(np.radians(input_df["receiverdir"]))

input_df["defender_pressure"] = (
    input_df["defenders_in_path"] * 
    np.where(input_df["receivera"] < 0, 1.5, 1.0) *  # Amplify if decelerating
    (1 / (input_df["distance_to_nearest_def"] + 0.5)  # Inverse distance weighting
))

# Create tackle probability feature
input_df["tackle_indicators"] = (
    (input_df["defenders_in_path"] >= 2) & 
    (input_df["receivera"] < 0)
).astype(int)


# Prepare features and target
ranking_test = input_df[[
    "friends_bucket",
    "defender_separation_encoded",
    "blocking_advantage",
    "separation_x_pass_length",
    "receiverx",
    "receivery",
    "receivers",
    "receivera",
    "receiverdis",
    #"receivero",
    "receiverdir",
    "defenders_in_path",
    "pass_length",
    #"yards_to_go",
    "receiver_momentum" ,
    "defender_density_ratio" ,
    "receiver_near_sideline",
    "defender_pressure",
    "tackle_indicators",
    "distance_to_nearest_def"
]].copy()
 
ranking_test = xgb.DMatrix(ranking_test)

#Model can now be used for predictions
ranking_pred = model.predict(ranking_test)

print(ranking_pred)
predicted_classes = np.argmax(ranking_pred, axis=1)
print(predicted_classes)

results = pd.DataFrame({
    'receiverID': input_df["receiverID"],
    'predicted_class': predicted_classes,
    'pass_length': pass_lengths
})

print(results)

#Deciding rankings

#If a maximum throw distance is given, exclude passes that are too far for the user
#sample_max_throw_dist = 12

#results now only includes passes that are within the players range
#results = results[results["pass_length"] <= sample_max_throw_dist]

rankings = results.sort_values(by=['predicted_class', 'pass_length'], ascending=[False, True])

#Add a rank column starting at 1
rankings["rank"] = range(1, len(rankings) + 1)

print(rankings)